package com.example.hibernate1.demohibernate.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.hibernate1.demohibernate.model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
}
