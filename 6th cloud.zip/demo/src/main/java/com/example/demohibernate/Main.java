package com.example.demohibernate;


import com.example.demohibernate.entity.Student1;
import com.example.demohibernate.entity.StudentManager;

public class Main {
    public static void main(String[] args) {
        StudentManager manager = new StudentManager();

        // Insert a student
        Student1 stud = new Student1();
        stud.setId(21);
        stud.setName("meera");
        stud.setAge(26);
        manager.insertStudent(stud);

        // Retrieve a student by ID
        Student1 foundStudent = manager.searchStudentById(5);
        if (foundStudent != null) {
            System.out.println("Found Student: " + foundStudent.getName() + ", Age: " + foundStudent.getAge());
        }

        // Update the student's age
        manager.updateStudentAge(11, 22);

        // Delete the student
        manager.deleteStudent(13);
    }
}
