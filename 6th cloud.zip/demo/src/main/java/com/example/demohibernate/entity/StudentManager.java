package com.example.demohibernate.entity;

import org.hibernate.Session;

import com.example.demohibernate.util.HibernateUtil;

public class StudentManager {
public void insertStudent(Student1 student) {
try (Session session = HibernateUtil.getSession()) {
session.beginTransaction();
session.save(student);
session.getTransaction().commit();
}
}

public Student1 searchStudentById(int id) {
try (Session session = HibernateUtil.getSession()) {
return session.get(Student1.class, id);
}
}

public void updateStudentAge(int id, int newAge) {
try (Session session = HibernateUtil.getSession()) {
session.beginTransaction();
Student1 student = session.get(Student1.class, id);
if (student != null) {
student.setAge(newAge);
session.update(student);
session.getTransaction().commit();
}
}
}

public void deleteStudent(int id) {
try (Session session = HibernateUtil.getSession()) {
session.beginTransaction();
Student1 student = session.get(Student1.class, id);
if (student != null) {
session.delete(student);
session.getTransaction().commit();
}
}
}
}
