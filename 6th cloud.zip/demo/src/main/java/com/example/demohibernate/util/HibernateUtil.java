package com.example.demohibernate.util;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.example.demohibernate.entity.Student1;


public class HibernateUtil {
    private static SessionFactory sessionFactory;

    static {
        try {
            sessionFactory = new Configuration()
                .configure("hibernate.cfg.xml")
                .addAnnotatedClass(Student1.class)
                .buildSessionFactory();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static org.hibernate.Session getSession() {
        return sessionFactory.openSession();
    }
}
