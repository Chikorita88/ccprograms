package com.example.demohibernate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemohibernateApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemohibernateApplication.class, args);
	}

}
