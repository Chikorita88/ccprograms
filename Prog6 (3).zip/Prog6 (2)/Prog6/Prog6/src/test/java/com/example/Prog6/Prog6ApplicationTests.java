package com.example.Prog6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Prog6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
