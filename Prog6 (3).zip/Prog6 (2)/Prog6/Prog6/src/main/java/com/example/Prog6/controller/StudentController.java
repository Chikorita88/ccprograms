package com.example.Prog6.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.Prog6.model.Student;
import com.example.Prog6.service.StudentService;

@RestController
@RequestMapping("/students")
public class StudentController {

    @Autowired
    private StudentService service;

    @PostMapping
    public Student create(@RequestBody Student student) {
        return service.save(student);
    }

    @GetMapping
    public List<Student> getAll() {
        return service.findAll();
    }

    @GetMapping("/{id}")
    public Student getById(@PathVariable int id) {
        return service.findById(id).orElse(null);
    }

    @PutMapping("/{id}")
    public Student update(@PathVariable int id, @RequestBody Student updatedStudent) {
        return service.updateAge(id, updatedStudent.getAge());
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable int id) {
        service.deleteById(id);
    }
}
