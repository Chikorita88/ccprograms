package com.example.Prog6;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.Prog6.model.Student;
import com.example.Prog6.service.StudentService;

@SpringBootApplication
public class Prog6Application implements CommandLineRunner {

    @Autowired
    private StudentService studentService;

    public static void main(String[] args) {
        SpringApplication.run(Prog6Application.class, args);
    }
    @Override
    public void run(String... args) throws Exception {
        Student student = new Student();
        student.setId(9);
        student.setName("Afnan");
        student.setAge(21);
        student.setNumber(89898766);

        studentService.save(student);

        System.out.println("Student values inserted!");
    }
}
